package com.pardot.lists;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class email {
	WebDriver driver;
	
	@FindBy(xpath="//*[@id='mark-tog']/span")
	WebElement marketing;

	@FindBy(xpath="//*[@id='dropmenu-marketing']/li[7]/a")
	//   //a[text()='Emails'") or //a[starts-with(@href, '/book/')]
	WebElement email;

	@FindBy(xpath="//*[@id='em_module']/div[1]/span/a")
	//	+ "//*[@id='dropmenu-marketing']/li[7]/ul/li[9]/a")
	//*[@id='em_module']/div[1]/span/a
	// //a[text()='New List Emails'") OR //a[starts-with(@href, '/email/draft/edit')]
	WebElement newListEmail;
	
	@FindBy(xpath="//*[@id='name']")
	WebElement name;
	
	@FindBy(xpath="//*[@id='tags_no_id_piEmailDraft_tagsinput']")
	WebElement tag;
	
	@FindBy(xpath="//*[@id='information_form']/div[4]/div/div/button")
	WebElement campaign;

	@FindBy(xpath="//*[@id='save_information']")
	WebElement saveEmail;
	
	public email(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	private void clickMarket() {
		marketing.click();
	}

	private void clickEmail() {
		email.click();
	}
	
	private void clickNewEmail() {
		newListEmail.click();
	}
	
	private void setname(String Name) {
		name.clear();
		name.sendKeys(Name);
	}

	private void setTag(String Tag) {
		tag.sendKeys(Tag);
	}
	
	private void setCampaign() {
		campaign.click();
	}
	
	private void save(){
		saveEmail.click();
	}
	public void navToListEmail(String name, String tag){
		this.clickMarket();
		this.clickEmail();
		this.clickNewEmail();
		
		//Maybe add some wait
		
		this.setname(name);
		//this.setTag(tag);
		this.setCampaign();
		WebElement campaignSearch= driver.findElement(By.xpath(".//*[@id='ember467']"));
		campaignSearch.sendKeys("Andy Indians");
		campaignSearch.sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//*[@id='ember1202']/div/div[1]/h4")).click();
		
		driver.findElement(By.xpath("//*[@id='select-asset']")).click();
		
		driver.findElement(By.xpath(".//*[@id='email_types']/div/label[2]/strong")).click(); //to set the text() email
		
		this.save();
	}
}