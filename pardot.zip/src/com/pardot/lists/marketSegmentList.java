package com.pardot.lists;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class marketSegmentList {

WebDriver driver;
	
    createList createLst = null;
    renameList renameLst = null;
    
	@FindBy(xpath="//*[@id='mark-tog']/span")
	WebElement marketing;
	
	@FindBy(xpath="//*[@id='dropmenu-marketing']/li[11]/a")
	WebElement marketSegment;
	
	@FindBy(xpath="//*[@id='dropmenu-marketing']/li[11]/ul/li[1]/a")
	WebElement marketSegmentList;
	
	@FindBy(xpath="//*[@id='center-stage']/ul/li[1]/a")
	WebElement hiddenListLink;
	
	@FindBy(xpath="//*[@id='listxistx_link_create']")
	WebElement addList;

	public marketSegmentList(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	};
	
	private void clickMarketing() {
		marketing.click();
	}

	private void clickMarketSegment() {
		marketSegment.click();
	}

	private void clickAddList() {
		addList.click();
	}
	
	public String navToListsAndCreateList(String listName, String tag){
		//webDriver Wait for 'Add List'  or implicit wait can be added here since the element does not load
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		this.clickMarketing();
		this.clickMarketSegment();

		//Add some more page factory methods for the WebDriver Wait
		WebDriverWait wait = new WebDriverWait( driver,300);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='listxistx_link_create']")));
		this.clickAddList();
		
		createLst = new createList(driver);
		
		return (createLst.createLst(listName, tag));
	}
	
	public String navToListsAndRenameList(String oldListName, String newListName){
		//webDriver Wait for 'Add List'  or implicit wait can be added here since the element does not load
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		this.clickMarketing();
		this.clickMarketSegment();

		WebDriverWait wait = new WebDriverWait( driver,300);
		/*wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='center-stage']/ul/li[1]/a"))); */
		String xPathListName="//a[text()='"+oldListName+"']";
		System.out.println("xPathListName + " + xPathListName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xPathListName)));
		driver.findElement(By.xpath(xPathListName)).click();
		
		driver.findElement(By.xpath("//*[@id='center-stage']/ul/li[1]/a")).click();
		
		renameLst = new renameList(driver);
		renameLst.changeListName(newListName);
		return null;
	}	
}
