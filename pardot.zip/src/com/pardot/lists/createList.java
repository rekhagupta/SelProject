package com.pardot.lists;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class createList {
	
	WebDriver driver;
	
	@FindBy(xpath="//*[@id='name']")
	WebElement listName;
	
	@FindBy(xpath="//*[@id='li_form_update']/div[2]/div/div[1]/span[2]")
	WebElement folderName;
	
	@FindBy(xpath="//*[@id='tags_no_id_Listx_tag']")
	WebElement tag;
	
	@FindBy(xpath="//*[@id='save_information']")
	WebElement saveBtn;
	
	@FindBy(xpath="//*[@id='li_form_update']/div[1]")
	WebElement listNameError;
	
	@FindBy(xpath="//*[@id='error_for_name']")
	WebElement duplicateListError;
	
	@FindBy(xpath="//*[@id='cancel_information']")
	WebElement cancelCreate;
	
	String title;
	String err;
	
	public createList(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	};

	private void setListName(String myListName) {
		listName.sendKeys(myListName);
	}
	
	private void setTag(String tagName) {
		tag.sendKeys(tagName);
	}

	private void clickSave() {
		saveBtn.click();
	}
	
	private void cancelListCreate() {
		cancelCreate.click();
	}
	
	public String getTitle() {
		return title;
	}
	
	private void setDuplicateListError(){
	    err = this.duplicateListError.getText();	
	}
	
	public String getDuplicateListError() {
		return err;
	}
		
	private void setTitle(){
		title=driver.getTitle();
	}
	
	public String createLst(String listName, String tag){
		//Add try-catch handling if elements are not found
		this.setListName(listName);
		this.setTag(tag);
		this.clickSave();
	
		WebDriverWait wait = new WebDriverWait( driver,300);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='center-stage']/ul/li[1]/a")));
		
		this.setTitle();
		this.setDuplicateListError();
		
		this.cancelListCreate();
		return err;		
	}
}
