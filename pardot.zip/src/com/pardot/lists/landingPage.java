package com.pardot.lists;

import org.openqa.selenium.WebDriver;

public class landingPage {

	WebDriver driver;
	public marketSegmentList msl;
	public prospectList pl;
	public email email;
	
	
	public landingPage(WebDriver driver){
		this.driver=driver;
	};


		
	public void navToProspects(String firstName, String lastName, String email, String listName){
		pl = new prospectList(driver);
		pl.navToProspectListAndCreate(firstName, lastName, email, listName);
		
	}
	
	public String navToMarketSegmentListAndCreateList(String listName, String tag){
		
		msl=new marketSegmentList(driver);
		return (msl.navToListsAndCreateList(listName, tag));
		
	}
	
	public String renameList(String oldListName, String newListName){

		msl=new marketSegmentList(driver);
		return (msl.navToListsAndRenameList(oldListName, newListName));
	}
	
	public void sendEmailToList(String name, String tag){
		email = new email(driver);
		email.navToListEmail(name, tag);
	}
}
