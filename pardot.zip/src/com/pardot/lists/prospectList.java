package com.pardot.lists;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class prospectList {

WebDriver driver;

	createProspect createProspect=null;
	
	@FindBy(xpath="//*[@id='pro-tog']/span")
	WebElement prospect;
	
	@FindBy(xpath="//*[@id='dropmenu-prospects']/li[1]/a")
	WebElement prospectList;
	
	@FindBy(xpath="//*[@id='pr_link_create']")
	WebElement addProspect;

	public prospectList(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	};
	
	private void clickProspect() {
		prospect.click();
	}

	private void clickProspectList() {
		prospectList.click();
	}


	private void clickAddProspect() {
		addProspect.click();
	}
	
	public void navToProspectListAndCreate(String fName, String lName, String email, String listName){
		//webDriver Wait for 'Add List'  or implicit wait can be added here since the element does not load
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		this.clickProspect();
		this.clickProspectList();

		WebDriverWait wait = new WebDriverWait( driver,300);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='pr_link_create']")));
		this.clickAddProspect();
		
		createProspect = new createProspect(driver);
		createProspect.addNewProspect(fName, lName, email, listName);
		
		
	}
}
