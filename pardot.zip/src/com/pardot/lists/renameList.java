package com.pardot.lists;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class renameList {
WebDriver driver;
	
	@FindBy(xpath="//*[@id='name']")
	WebElement listName;
	
	@FindBy(xpath="//*[@id='save_information']")
	WebElement saveBtn;
	
	public renameList(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	};

	private void setListName(String myListName) {
		listName.clear();
		listName.sendKeys(myListName);
	}
	
	private void clickSave() {
		saveBtn.click();
	}
	
	public void changeListName( String newListName){
		this.setListName(newListName);
		this.clickSave();
	}
}
