package com.pardot.lists;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class createProspect {
	WebDriver driver;
	
	@FindBy(xpath="//*[@id='default_field_3361']")
	WebElement firstName;
	
	@FindBy(xpath="//*[@id='default_field_3371']")
	WebElement lastName;
	
	@FindBy(xpath="//*[@id='email']")
	WebElement email;
	
	@FindBy(xpath="//*[@id='campaign_id']/optgroup[1]/option[3]")
	WebElement campaign;
	
	@FindBy(xpath="//*[@id='profile_id']")
	WebElement profile;
	
	@FindBy(xpath="//*[@id='pr_form_update']/form/div[21]/input")
	WebElement saveProspect;
	
	public createProspect(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	private void setFirstName(String fName) {
		firstName.sendKeys(fName);
	}

	private void setLastName(String lName) {
		lastName.sendKeys(lName);
	}
	
	private void setEmail(String eMail) {
		email.sendKeys(eMail);
	}
	
	private void clickSave() {
		saveProspect.click();
	}
	
	public void addNewProspect(String firstName, String lastName, String email, String listName){ //, String campaign, String profile){
		
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setEmail(email);
		Select select = new Select(driver.findElement(By.xpath("//*[@id='campaign_id']")));
		//select.deselectAll();
		select.selectByIndex(1);
		
		select = new Select(driver.findElement(By.xpath("//*[@id='profile_id']")));
		//select.deselectAll();
		select.selectByIndex(1);

		driver.findElement(By.xpath("//*[@id='pr_form_update']/form/div[20]/h4")).click();
		
		select = new Select(driver.findElement(By.xpath("//*[@id='selX80_chzn']/a/div/b")));
		select.selectByValue(listName);
		
		this.clickSave();
	}
}
