package com.pardot.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.pardot.lists.landingPage;

public class login{
	WebDriver driver;
	
	@FindBy(xpath="//*[@id='email_address']")
	WebElement EMAIL;
	
	@FindBy(xpath="//*[@id='password']")
	WebElement PASSWORD;
	
	@FindBy(xpath="//input[@name='commit']")
	WebElement LOGIN_BUTTON;
	
	String title;
	
	public login(WebDriver driver){
		this.driver=driver;
	};

	public void setEMAIL(String emailAddress) {
		EMAIL.sendKeys(emailAddress);
	}

	public void setPASSWORD(String password) {
		PASSWORD.sendKeys(password);
	}

	public void setLOGIN_BUTTON() {
		LOGIN_BUTTON.click();
	}
	
	public String getTitle() {
		return title;
	}
	
	private void setTitle(){
		title=driver.getTitle();
	}

	public landingPage pardotLogin(String email, String passwd){
		this.setEMAIL(email);
		this.setPASSWORD(passwd);
		this.setLOGIN_BUTTON();
		this.setTitle();
		
		if(!title.toLowerCase().contains("dashboard")) // not logged in meaning no  landing page
			return null;
		else{//logged in success
		landingPage landingPage = PageFactory.initElements(driver, landingPage.class);
		return landingPage;
		}
	}
}