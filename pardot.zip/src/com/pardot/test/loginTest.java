package com.pardot.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pardot.lists.landingPage;
import com.pardot.login.login;

public class loginTest {
	
	WebDriver driver;
	login login;
	landingPage landing = null;

  //This will instantiate the driver. Currently only chrome is implemented
  // TO DO : read the login details from properties file OR xls file as appropriate
  //Code can be changed to run on multiple browsers as needed ('BROWSER' property can be read from a config file e.g.)
  // TO Do :  More changes I can make are : Make Webdriver a Singleton Method to control one instance creation.
  // Cleanup the code implementing some scattered web element locators using page factory for better maintenance
  
  // The Framework is developed using the Page Object and Page Factory Model. More changes can be done to the code to make it resistant to UI changes
  // Currently all test cases are running and working, but chromeDriver can cause failure in selecting elements.
  
  // After successful Login, user will goto 'LandingPage' which HAS-A MarketSegmentList and ProspectList and Email Generation. This is the base of the framework.
  // To DO: add testng.xml to create a suit, package for running the test cases
  // To DO: More Error handling, integrated with testng "expectedExceptions" need to be implemented
	
  @BeforeTest
  public void setup() {
	  System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\chromedriver.exe");
      driver = new ChromeDriver();
      driver.manage().window().maximize();
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      driver.get("http://pi.pardot.com");
  }
  
  //Login to Pardot
  //@Params : UserName, Password
  //Assert with checks to make sure that user has logged in
  //TO DO: the data can be read from a properties file/xls spreadsheet e.g if need to test logins with multiple users with different profiles
  //More Error handling in the test cases
  
  @Test (priority=0)
  public void loginPardot(){
	  login lp = PageFactory.initElements(driver, login.class);
	  
	  landing = lp.pardotLogin("pardot.applicant@pardot.com", "Applicant2012");
	  String title = lp.getTitle();
	  System.out.println("title + " + title );
	  Assert.assertTrue(title.toLowerCase().contains("dashboard"));
  }

  @Test (priority=1, dependsOnMethods={"loginPardot"}) 
  public void createNewList(){
	  String retStr= landing.navToMarketSegmentListAndCreateList("Pardot-RG2", "Pardot");
	  String expectedResult="";
	  Assert.assertTrue(retStr.contains(expectedResult));
  }
  
  //Create a ORIGINAL List
  //@Params : List Name, Tag
  //Assert to make sure the return string comes back with error message 
  @Test (priority=2, dependsOnMethods={"loginPardot"}) 
  public void createDuplicateList(){
	  String retStr= landing.navToMarketSegmentListAndCreateList("Pardot-RG2", "Pardot");
	  String expectedResult="Please input a unique value for this field";
	  Assert.assertTrue(retStr.contains(expectedResult));
  }
  
  //Rename an existing Original List
  //@Params : Old List Name, New List Name
  @Test (priority=3, dependsOnMethods={"loginPardot"})
  public void renameExistingList(){
	  landing.renameList("Pardot-RG2","Pardot-RG2-modified");
  }
  
  //Create a List with Original Name
  //@Params : List Name, Tag
  //Assert to make sure the return string comes back with message
  @Test (priority=4, dependsOnMethods={"loginPardot"}) 
  public void createList(){
	  String retStr= landing.navToMarketSegmentListAndCreateList("Pardot-RG2", "Pardot");
	  String expectedResult="Please input a unique value for this field";
	  Assert.assertTrue(retStr.contains(expectedResult));
  }
  
  // Create a new prospect (Prospect > Prospect List) and add the List to it
  //@Params : First Name, LastName, Email, List Name
  @Test (priority=5, dependsOnMethods={"loginPardot"}) 
  public void createProspect(){
	  landing.navToProspects("Applicant", "Pardot", "applicant.pardot@pardot.com", "Pardot-RG2"); 
  }
  
  //Send a text only email to the list (Marketing > Emails) 
  //@Params : Name, Tag
  @Test(dependsOnMethods={"loginPardot"})
  public void composeAndSendEmail(){
      landing.sendEmailToList("Dear Prospect", "Welcome to Pardot!");
  } 
  
  @AfterTest()
  public void tearDown(){
	  driver.quit();
  }
}